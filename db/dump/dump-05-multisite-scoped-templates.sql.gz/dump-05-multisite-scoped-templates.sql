-- MySQL dump 10.11
--
-- Host: localhost    Database: radiant_pkg_development
-- ------------------------------------------------------
-- Server version	5.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL auto_increment,
  `caption` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `asset_file_name` varchar(255) default NULL,
  `asset_content_type` varchar(255) default NULL,
  `asset_file_size` int(11) default NULL,
  `created_by_id` int(11) default NULL,
  `updated_by_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assets`
--

/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` int(11) NOT NULL auto_increment,
  `key` varchar(40) NOT NULL default '',
  `value` varchar(255) default '',
  `description` text,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `config`
--

/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` VALUES (1,'admin.title','Radiant CMS','Title text displayed at the top of all administration screens.'),(2,'admin.subtitle','Publishing for Small Teams','The tagline displayed underneath the main administration title'),(3,'defaults.page.parts','body, extended, sidebar','Defines the page parts that a new page is created with.  It should be a list, separated by a comma and a space.  For example:\n\nbq. @body, extended, sidebar@\n'),(4,'defaults.page.status','published','Defines the publishing status of new pages.  This can any one of:\n\n* draft\n* published\n* reviewed\n* hidden\n'),(5,'defaults.page.filter','WymEditor','Sets the text filter a new page has by default.  Valid options, in a vanilla Radiant install are:\n\n* _leave blank to set no default filter_\n* Markdown\n* SmartyPants\n* Textile\n'),(6,'session_timeout','1209600',NULL),(7,'roles.settings','admin','List of user roles that may see the settings tabs.'),(8,'assets.additional_thumbnails','normal=640x640>','Defines the default sizes for image assets that are created when an image is uploaded. Use \"#\" to crop the image to a specific size. \"42x42#\" would be a square thumbnail, cropped in the center 42 pixels by 42 pixels.'),(9,'assets.display_size','original','Sets which of your image sizes is shown is the edit view. Defaults to the \"original\" image size, but any size may be used. '),(10,'assets.content_types','image/jpeg, image/pjpeg, image/gif, image/png, image/x-png, image/jpg, video/x-m4v, video/quicktime, application/x-shockwave-flash, audio/mpeg, video/mpeg','Defines the content types of that will be allowed to be uploaded as assets.'),(11,'assets.max_asset_size','5','The size in megabytes that will be the max size allowed to be uploaded for an asset'),(12,'assets.skip_filetype_validation','true',NULL),(13,'SnS.stylesheet_directory','css',NULL),(14,'SnS.javascript_directory','js',NULL);
/*!40000 ALTER TABLE `config` ENABLE KEYS */;

--
-- Table structure for table `extension_meta`
--

DROP TABLE IF EXISTS `extension_meta`;
CREATE TABLE `extension_meta` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `schema_version` int(11) default '0',
  `enabled` tinyint(1) default '1',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `extension_meta`
--

/*!40000 ALTER TABLE `extension_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `extension_meta` ENABLE KEYS */;

--
-- Table structure for table `layouts`
--

DROP TABLE IF EXISTS `layouts`;
CREATE TABLE `layouts` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) default NULL,
  `content` text,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `created_by_id` int(11) default NULL,
  `updated_by_id` int(11) default NULL,
  `content_type` varchar(40) default NULL,
  `lock_version` int(11) default '0',
  `site_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `layouts`
--

/*!40000 ALTER TABLE `layouts` DISABLE KEYS */;
INSERT INTO `layouts` VALUES (1,'normal','<r:snippet name=\"header\" />\r\n<r:snippet name=\"masthead\" />\r\n\r\n<div class=\"container\" id=\"content-wrapper\">\r\n  <div class=\"span-20\" id=\"left\">\r\n		<h2>Left column</h2>\r\n		<r:nav include_root=\"true\" depth=\"3\" />\r\n	</div>\r\n\r\n  <div class=\"col span-55\" id=\"content\">\r\n  	<div class=\"box\">\r\n  	<h1>Main content</h1>\r\n		<r:content />\r\n    <r:if_content part=\"extended\">\r\n    <div id=\"extended\">\r\n      <r:content part=\"extended\" />\r\n    </div>\r\n    </r:if_content>\r\n    </div>\r\n  </div>\r\n\r\n  <div class=\"col span-20\" id=\"right\">\r\n  	<h3>Right column</h3>\r\n		<r:content part=\"sidebar\" inherit=\"true\" />\r\n  </div>\r\n</div>\r\n\r\n<r:snippet name=\"footer\" />\r\n','2009-10-27 09:24:54','2009-10-27 10:27:47',1,1,'',4,2);
/*!40000 ALTER TABLE `layouts` ENABLE KEYS */;

--
-- Table structure for table `page_attachments`
--

DROP TABLE IF EXISTS `page_attachments`;
CREATE TABLE `page_attachments` (
  `id` int(11) NOT NULL auto_increment,
  `asset_id` int(11) default NULL,
  `page_id` int(11) default NULL,
  `position` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `page_attachments`
--

/*!40000 ALTER TABLE `page_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `page_attachments` ENABLE KEYS */;

--
-- Table structure for table `page_parts`
--

DROP TABLE IF EXISTS `page_parts`;
CREATE TABLE `page_parts` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) default NULL,
  `filter_id` varchar(25) default NULL,
  `content` text,
  `page_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `parts_by_page` (`page_id`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `page_parts`
--

/*!40000 ALTER TABLE `page_parts` DISABLE KEYS */;
INSERT INTO `page_parts` VALUES (1,'body','WymEditor',NULL,1),(2,'extended','WymEditor',NULL,1),(3,'body','WymEditor','<h1>\r\n  Main site\r\n</h1>',2),(4,'extended','WymEditor','',2),(5,'body','WymEditor','<h1>\r\n  Alternate site\r\n</h1>',3),(6,'extended','WymEditor','',3);
/*!40000 ALTER TABLE `page_parts` ENABLE KEYS */;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) default NULL,
  `slug` varchar(100) default NULL,
  `breadcrumb` varchar(160) default NULL,
  `class_name` varchar(25) default NULL,
  `status_id` int(11) NOT NULL default '1',
  `parent_id` int(11) default NULL,
  `layout_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `published_at` datetime default NULL,
  `created_by_id` int(11) default NULL,
  `updated_by_id` int(11) default NULL,
  `virtual` tinyint(1) NOT NULL default '0',
  `lock_version` int(11) default '0',
  `description` varchar(255) default NULL,
  `keywords` varchar(255) default NULL,
  `position` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `pages_class_name` (`class_name`),
  KEY `pages_parent_id` (`parent_id`),
  KEY `pages_child_slug` (`slug`,`parent_id`),
  KEY `pages_published` (`virtual`,`status_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pages`
--

/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'default_site Homepage','default_site','Home',NULL,100,NULL,NULL,'2009-10-25 22:18:45','2009-10-25 22:18:45','2009-10-25 23:18:45',NULL,NULL,0,0,NULL,NULL,NULL),(2,'Main site Homepage','main-site','Home','',100,NULL,1,'2009-10-25 22:20:31','2009-10-27 09:26:00','2009-10-25 23:20:31',1,1,0,2,'','',NULL),(3,'Alternate site Homepage','alternate-site','Home','',100,NULL,NULL,'2009-10-25 22:22:30','2009-10-25 22:24:08','2009-10-25 23:22:30',1,1,0,1,'','',NULL);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schema_migrations`
--

/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('1'),('10'),('11'),('12'),('13'),('14'),('15'),('16'),('17'),('18'),('19'),('2'),('20'),('20081203140407'),('21'),('3'),('4'),('5'),('6'),('7'),('8'),('9'),('Drag Order-1'),('Multi Site-1'),('Multi Site-2'),('Multi Site-20090810145840'),('Multi Site-3'),('Multi Site-4'),('Paperclipped-1'),('Paperclipped-2'),('Paperclipped-20090316132151'),('Paperclipped-3'),('Paperclipped-4'),('Paperclipped-5'),('Paperclipped-6'),('Paperclipped-7'),('Scoped Admin-1'),('Scoped Admin-2'),('Scoped Admin-3'),('Settings-1'),('Settings-2'),('Styles \'n Scripts-1'),('Styles \'n Scripts-2'),('Styles \'n Scripts-3'),('Styles \'n Scripts-4'),('Submenu-20091003125321');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL auto_increment,
  `session_id` varchar(255) default NULL,
  `data` text,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_sessions_on_session_id` (`session_id`),
  KEY `index_sessions_on_updated_at` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sessions`
--

/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
CREATE TABLE `sites` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `domain` varchar(255) default NULL,
  `homepage_id` int(11) default NULL,
  `position` int(11) default '0',
  `base_domain` varchar(255) default NULL,
  `created_by_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_by_id` int(11) default NULL,
  `updated_at` datetime default NULL,
  `subtitle` varchar(255) default NULL,
  `abbreviation` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sites`
--

/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,'default_site','',1,1,'localhost',NULL,'2009-10-25 22:18:45',NULL,'2009-10-25 22:18:45',NULL,NULL),(2,'Main site','(demo|dev|test|www).radiant-pkg$',2,2,'radiant-pkg',NULL,'2009-10-25 22:20:31',NULL,'2009-10-25 22:20:31','',NULL),(3,'Alternate site','(demo|dev|test|www).radiant-pkg.alt$',3,3,'radiant-pkg.alt',NULL,'2009-10-25 22:22:30',NULL,'2009-10-25 22:22:30','',NULL);
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;

--
-- Table structure for table `snippets`
--

DROP TABLE IF EXISTS `snippets`;
CREATE TABLE `snippets` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `filter_id` varchar(25) default NULL,
  `content` text,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `created_by_id` int(11) default NULL,
  `updated_by_id` int(11) default NULL,
  `lock_version` int(11) default '0',
  `site_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `snippets`
--

/*!40000 ALTER TABLE `snippets` DISABLE KEYS */;
INSERT INTO `snippets` VALUES (1,'masthead','','    <div class=\"container\">\r\n      <div id=\"header\" class=\"span-95\">\r\n        <div id=\"logo\" class=\"span-20\">\r\n          <a href=\"URL\" title=\"title\">company logo here</a>\r\n        </div>\r\n        <div id=\"nav\" class=\"span-75\">\r\n          <r:nav include_root=\"true\" depth=\"1\" />\r\n        </div>\r\n      </div>\r\n    </div>','2009-10-27 09:18:00','2009-10-27 09:57:10',1,1,2,2),(2,'header','','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\r\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">\r\n<head>\r\n	<title><r:title /></title>\r\n	<script src=\"/js/lib/jquery.min.js\" type=\"text/javascript\"></script>\r\n	<script src=\"/js/util.js\" type=\"text/javascript\"></script>\r\n	<link rel=\"stylesheet\" href=\"/css/framework-bpg/screen.css\" type=\"text/css\" media=\"screen, projection\" />\r\n	<link rel=\"stylesheet\" href=\"/css/framework-bpg/gutterless.css\" type=\"text/css\" media=\"screen, projection\" />\r\n	<link rel=\"stylesheet\" href=\"/css/framework-bpg/print.css\" type=\"text/css\" media=\"print\" />\r\n	<!--[if IE]><link rel=\"stylesheet\" href=\"/css/framework-bpg/ie.css\" type=\"text/css\" media=\"screen, projection\" /><![endif]-->\r\n\r\n	<link rel=\"stylesheet\" href=\"/css/global.css\" type=\"text/css\" media=\"screen, projection\" />\r\n	<link rel=\"stylesheet\" href=\"/css/print.css\" type=\"text/css\" media=\"print\" />\r\n</head>\r\n<body>','2009-10-27 09:19:00','2009-10-27 10:25:21',1,1,8,2),(3,'footer','','    <div class=\"container\" id=\"footer\">\r\n	<h4>Footer</h4>\r\n<p>Add footer page to snippet.</p>\r\n    </div>\r\n  </body>\r\n</html>','2009-10-27 09:21:06','2009-10-27 09:25:10',1,1,1,2);
/*!40000 ALTER TABLE `snippets` ENABLE KEYS */;

--
-- Table structure for table `submenu_links`
--

DROP TABLE IF EXISTS `submenu_links`;
CREATE TABLE `submenu_links` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `url` varchar(255) default NULL,
  `user_id` int(11) default NULL,
  `site_id` int(11) default NULL,
  `created_by_id` int(11) default NULL,
  `updated_by_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_links_by_site_and_user` (`site_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `submenu_links`
--

/*!40000 ALTER TABLE `submenu_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `submenu_links` ENABLE KEYS */;

--
-- Table structure for table `text_asset_dependencies`
--

DROP TABLE IF EXISTS `text_asset_dependencies`;
CREATE TABLE `text_asset_dependencies` (
  `id` int(11) NOT NULL auto_increment,
  `text_asset_id` int(11) default NULL,
  `names` varchar(255) default NULL,
  `effectively_updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `text_asset_dependencies`
--

/*!40000 ALTER TABLE `text_asset_dependencies` DISABLE KEYS */;
/*!40000 ALTER TABLE `text_asset_dependencies` ENABLE KEYS */;

--
-- Table structure for table `text_assets`
--

DROP TABLE IF EXISTS `text_assets`;
CREATE TABLE `text_assets` (
  `id` int(11) NOT NULL auto_increment,
  `class_name` varchar(25) default NULL,
  `name` varchar(100) default NULL,
  `content` text,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `created_by_id` int(11) default NULL,
  `updated_by_id` int(11) default NULL,
  `lock_version` int(11) default NULL,
  `filter_id` varchar(25) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `text_assets`
--

/*!40000 ALTER TABLE `text_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `text_assets` ENABLE KEYS */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) default NULL,
  `email` varchar(255) default NULL,
  `login` varchar(40) NOT NULL default '',
  `password` varchar(40) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `created_by_id` int(11) default NULL,
  `updated_by_id` int(11) default NULL,
  `admin` tinyint(1) NOT NULL default '0',
  `developer` tinyint(1) NOT NULL default '0',
  `notes` text,
  `lock_version` int(11) default '0',
  `salt` varchar(255) default NULL,
  `session_token` varchar(255) default NULL,
  `site_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Administrator',NULL,'admin','41a3495782fd8b9d2211ef1d76d9100fe7198499','2009-10-25 21:10:28','2009-10-25 22:31:27',NULL,NULL,1,0,NULL,1,'d0631e03ef7177ff607e8311597009db837e4dfd',NULL,2);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-10-27 10:30:40
